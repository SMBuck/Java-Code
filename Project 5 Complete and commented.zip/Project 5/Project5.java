import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * This class includes a main method and 3 boundary methods. The main method only invokes the boundary methods that sort and organize data from a file. The bondary method readData
 * takes the data and sort through it putting the correct variables into an object called Shipment then creats an ArrayList of those objects. Then the next boundary class sortData takes
 * that ArrayList and sorts through based on volume and weight and loads it into a mailcoach object and then creates an ArrayList of those objects. The print report Method prints a report
 * of the shipments to each destination by traversing through each ArrayList. 
 */

public class Project5 {
    //DATE AND TIME YOU FIRST START WORKING ON THIS ASSIGNMENT (date AND time): <--------------------
    //ANSWER:    10/27/2022 1900            <--------------------
    
    //DO NOT ALTER THE MAIN METHOD
    public static void main( String[] args ) {
        //test your entity classes, comment out when you passed all tests
        //testShipment();
        //testMailCoach();
        
        //readData reads the input file into an array list
        //it fills the array list with Shipment objects
        ArrayList< Shipment > allMail = readData( "week1.txt" );
        
        //sortData goes through the raw data contained in all mail and populates
        //an array list for the destination with MailCoach objects
        ArrayList< MailCoach > stolat = sortData( "Stolat", allMail );
        ArrayList< MailCoach > quirm = sortData( "Quirm", allMail );
        ArrayList< MailCoach > pseudopolis = sortData( "Pseudopolis", allMail );
        ArrayList< MailCoach > borogravia = sortData( "Borogravia", allMail );
        ArrayList< MailCoach > ueberwald = sortData( "Ueberwald", allMail );
        ArrayList< MailCoach > krull = sortData( "Krull", allMail );
        
        //printReport prints the mail coach data dor each destination in turn
        printReport( stolat );
        printReport( quirm );
        printReport( pseudopolis );
        printReport( borogravia );
        printReport( ueberwald );
        printReport( krull );
    }//DO NOT ALTER THE MAIN METHOD
    public static void testShipment() { //DO NOT ALTER THIS METHOD
        Shipment s1 = new Shipment();
        assert s1.getDestination().equals( "" ) && s1.getVolume() == 0 && 
               s1.getId() == 0 && Math.abs( s1.getWeight() - 0 ) < 0.001 : "Shipment standard constructor not working";
        Shipment s2 = new Shipment( 44, "Stolat", 10.5, 13 );
        assert s2.getDestination().equals( "Stolat" ) : "Shipment second costructor destination not set correctly";
        assert s2.getVolume() == 13 : "Shipment second costructor volume not set correctly";
        assert s2.getId() == 44 : "Shipment second costructor id not set correctly";
        assert Math.abs( s2.getWeight() - 10.5 ) < 0.001 : "Shipment second costructor weight not set correctly";
        System.out.println( "Shipment all tests passed" );
    } //DO NOT ALTER THIS METHOD
    public static void testMailCoach() { //DO NOT ALTER THIS METHOD
        MailCoach mc1 = new MailCoach();
        assert mc1.getDestination().equals( "" ) && mc1.getVolume() == 0 && 
               Math.abs( mc1.getWeight() - 0 ) < 0.001 && mc1.getCargo() != null : "MailCoach standard constructor not working";
        MailCoach mc2 = new MailCoach( "Stolat" );  
        assert mc2.getDestination().equals( "Stolat" ) && mc2.getVolume() == 0 && 
               Math.abs( mc2.getWeight() - 0 ) < 0.001 && mc2.getCargo() != null : "MailCoach second constructor not working";
        Shipment s1 = new Shipment( 12, "Stolat", 106.7, 45 );
        Shipment s2 = new Shipment( 44, "Stolat", 10.5, 13 );
        mc2.addShipment( s1 );
        mc2.addShipment( s2 );
        assert mc2.getVolume() == 58 : "MailCoach addShipment not working";
        assert Math.abs( mc2.getWeight() - 117.2 ) < 0.001 : "MailCoach addShipment not working";
        assert mc2.getCargo().get( 0 ) == s1 : "MailCoach addShipment not working";
        assert mc2.getCargo().get( 1 ) == s2 : "MailCoach addShipment not working";
        System.out.println( "MailCoach all tests passed" );
    }//DO NOT ALTER THIS METHOD
    /**
     * @param takes a file name with shipment information of cargo going to certain destinations containing weight, volume, and id of that cargo. 
     * @returns ArrayList of Shipment objects created from the data in the file. 
     */
    public static ArrayList< Shipment > readData( String fileName ) {
        //IMPLEMENT THIS METHOD
        String file = fileName;
        Scanner reader = null;
        
        try{
            File input = new File(file);
            reader = new Scanner(input);
        }
        catch(FileNotFoundException e){
            System.out.print("File not found");
        }
        
        double cargoWeight;
        int cargoVolume ,cargoId, parseInt, parseIntId;
        String cargoDestination, deliveryDay, holder, holder2;
        
        /**
         * I created a new ArrayList of Shipment objects before entering the while loop. I then used a while loop on the condition of the text in the file and it will break once it 
         * reads through all the data. I then assigned certain variables above to hold certain parts of that data and then created a Shipment object with that data and then added it to
         * an ArrayList of Shipments called cargoShipment.
         */
        
        ArrayList< Shipment > cargoShipment = new ArrayList < Shipment > ();
        while(reader.hasNext()){
            cargoWeight = reader.nextDouble();
            reader.next();
            holder = reader.next();
            if(holder.length() > 3){
                parseInt = Integer.parseInt(holder.substring(1,3));
            }
            else{
                parseInt = Integer.parseInt(holder.substring(1,2));
            }
            cargoVolume = parseInt;
            reader.next();
            cargoDestination = reader.next();
            reader.next();
            reader.next();
            holder2 = reader.next();
            parseIntId = Integer.parseInt(holder2.substring(1));
            cargoId = parseIntId;
            Shipment s = new Shipment(cargoId, cargoDestination, cargoWeight, cargoVolume);
            cargoShipment.add(s);
        }
        reader.close();
        return cargoShipment;
    }
    /**
     * @param String destination, ArrayList of object Shipments
     * Takes the two parameters and iterates through the Arraylist of shipments. checks the destination, if they match then checks if the Mailcoach object can fit the volume and weight
     * of the shipment, loads it if it can or creates another MailCoach to load it on and loads each Mail coach into an ArrayList once all destinations are matched. 
     * @returns ArrayList of MailCoach objects. 
     */
    public static ArrayList< MailCoach > sortData( String destination, ArrayList< Shipment > allMail ) {
        //IMPLEMENT THIS METHOD
        ArrayList < MailCoach > sortData = new ArrayList < MailCoach > ();
        MailCoach m = new MailCoach(destination);
        sortData.add(m);
        
        String destinationHandle;
        /**
         * I used a nested loop to iterate through the ArrayList of shipments and check the destination, if it matches I then go into the nested loop and check if the MailCoach can 
         * fit the shipment. If it can it loads it, if not it creates another one. As each one is created once it enters the loop it checks if it can be loaded onto each one already
         * created and if it cannot and reaches the end it creates another. Once all Mailcoaches are created with the alloted volume and weight it returns an ArrayList of MailCoaches
         * with the loaded shipments on them for each destination when called in the main. 
         */
    
        for(int i = 0; i < allMail.size(); i++){
            destinationHandle = allMail.get(i).getDestination();
            if(destinationHandle.equals(destination)){
                for(int j = 0; j < sortData.size(); j++){
                    if(allMail.get(i).getVolume() + sortData.get(j).getVolume() <= 100 && allMail.get(i).getWeight() + sortData.get(j).getWeight() <= 500){
                        sortData.get(j).addShipment(allMail.get(i));
                        break;
                    }
                    else if(j == sortData.size() - 1) {
                        MailCoach m2 = new MailCoach(destination);
                        m2.addShipment(allMail.get(i));
                        sortData.add(m2);
                        break;
                    }
                }
            }
        }
        return sortData;
        }
    /**
     * @param ArrayList of MailCoaches
     * takes the array list and checks certain conditions to print to the screen of each destination. what shipments are on board and if its dispatched based on volume and weight. 
     * @returns void
     */   
    public static void printReport( ArrayList< MailCoach > mc ) {
        //IMPLEMENT THIS METHOD
        ArrayList < Shipment > cargoId;
        int printId;
        String status, totalId = "";
        
        /**
         * I used nested loop to iterate throught the Array list of mailcoaches, get the cargo on board, then enter a nested loop of that cargo to check the volume and weight. Based off
         * those variables I get the shipment Ids onboard and set the shipment to dispatch if it meets weight or volume criteria. HOLD if it doesnt or NO SHIPMENTS if theres nothing on
         * the MailCoach.
         */
        
        System.out.printf("Next week's mail coaches to %s:%n",mc.get(0).getDestination());
        for(int i = 0; i < mc.size(); i++){
            cargoId = mc.get(i).getCargo();
            if(mc.get(i).getVolume() >= 50 || mc.get(i).getWeight() >= 250){
                status = "DISPATCH:";
                System.out.printf("    %-8s coach %d ",status,i + 1);
                for(int j = 0; j < cargoId.size(); j++){
                    printId = cargoId.get(j).getId();
                    totalId = totalId + "#" + printId + " ";
                }
                System.out.printf("(shipments %s)%n",totalId.trim());
            }
            else if(mc.get(i).getVolume() > 0 || mc.get(i).getWeight() > 0){
                status = "HOLD:";
                System.out.printf("    %-9s coach %d ",status,i + 1); 
                for(int j = 0; j < cargoId.size(); j++){
                    printId = cargoId.get(j).getId();
                    totalId = totalId + "#" + printId + " ";
                }
                System.out.printf("(shipments %s)%n",totalId.trim()); 
            }
            else if(mc.get(i).getVolume() == 0 && mc.get(i).getWeight() == 0){
                System.out.printf("    NO SHIPMENTS%n");
            }
            totalId = "";
        }
        System.out.println();
    }
}
