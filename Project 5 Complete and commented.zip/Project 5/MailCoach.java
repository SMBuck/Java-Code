import java.util.ArrayList;
/**
 * Mailcoach class uses 4 instance variables, destination, weight, volume and cargo. Cargo being an ArrayList of the Shipment object to be loaded
 * onto the MailCoach.
 *
 * @author (Marshall Buck)
 * @version (10/27/2022)
 */
public class MailCoach
{
    private String destination;
    private double weight;
    private int volume;
    private ArrayList <Shipment> cargo;

    /**
     * Standard constructor for MailCoach
     */
    public MailCoach()
    {
        this.destination = "";
        this.weight = 0.0;
        this.volume = 0;
        this.cargo = new ArrayList <Shipment> ();
    }
    /**
     * Second constructor for MailCoach
     * @param takes the destination as a string
     * sets the destination to the param, initializes the other variables the same as the standard. 
     */
    public MailCoach(String destination){
        this.destination = destination;
        this.weight = 0.0;
        this.volume = 0;
        this.cargo = new ArrayList <Shipment> ();
    }

    /**
     * @param  none
     * @return  return destination as a string. 
     */
    public String getDestination(){
        return this.destination;
    }
    /**
     * @param none
     * @return returns volume as an int. 
     */
    public int getVolume(){
        return this.volume;
    }
    /**
     * @param none
     * @return returns weight as a double. 
     */
    public double getWeight(){
        return this.weight;
    }
    /**
     * @param none
     * @returns cargo as an array list of the Shipment objects. 
     */
    public ArrayList < Shipment > getCargo(){
        return this.cargo;
    }
    /**
     * @param Shipment object
     * accumulates the weight and volume of the shipment and loads the mail coach with the array list of the Shipment object. 
     * @returns void
     */
    public void addShipment(Shipment s){
        this.weight += s.getWeight();
        this.volume += s.getVolume();
        cargo.add(s);
    }
}

