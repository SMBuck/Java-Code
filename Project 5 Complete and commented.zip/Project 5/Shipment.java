
/**
 * This class is used to create a Shipment to be used for the Mail Coach. 
 *
 * @author (Marshall Buck)
 * @version (10/27/2022)
 */
public class Shipment
/**
 * Intialized instance variables for the Shipment class. 
 */
{
    // instance variables
    private String destination;
    private double weight;
    private int volume, id;

    /**
     * Standard constructor for the Shipment Class. 
     */
    public Shipment()
    {
        this.destination = "";
        this.weight = 0.0;
        this.volume = 0;
        this.id = 0;
    }
    /**
     * Second constructor for the Shipment Class.
     * 
     * @param takes the instance variables created in the class as parameters to set the values to enable the getters to have a value to return. 
     */
    public Shipment(int id, String destination, double weight, int volume){
        this.destination = destination;
        this.weight = weight;
        this.volume = volume;
        this.id = id;
    }
    
    /**
     * @param  takes no parameter
     * @return  a string of destination
     */
    public String getDestination(){
        return this.destination; 
    }
    /**
     * @param takes no parameter
     * @return a double of weight
     */
    public double getWeight(){
        return this.weight;
    }
    /**
     * @param takes no parameter
     * @return an int of volume
     */
    public int getVolume(){
        return this.volume;
    }
    /**
     * @param takes not parameter
     * @return an int of id
     */
    public int getId(){
        return this.id;
    }
}
