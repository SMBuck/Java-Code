
/**
 * The class Delivery takes creates and object with a standard constructor and a constructor with parameters filled in by an array of strings in 
 * the main method. It declares instance variables, initializes instance variables to base values and sets values based on the array of strings from the 
 * main. It only contains getters since the variables are all set by the main method. 
 *
 * @author (Marshall Buck)
 * @version (09/21/2022)
 */
public class Delivery
{
    // declaration of instance variables 
    private String reciever, origin, item;
    private boolean hazardous;
    private double fee;

    /**
     * Constructor for objects of class Delivery
     */
    public Delivery(){
        // intializing the instance variables to intial base value in standard constructor. 
        this.reciever = "";
        this.origin = "";
        this.item = "";
        this.hazardous = false;
        this.fee = 0.0; 
        
    }
    public Delivery(String reciever, String origin, String item, int numberOfItems,
    int weightPerItemInOz, String hazard)
    {
        /* initializing instance variables for the second constructor with parameters. hazardous is set with a condition based on the string to tell if 
         * its hazardous or not. The fee is set with conditions based on the string input to get the calculations to apply correctly for output of cost. 
         */ 
        this.reciever = reciever;
        this.origin = origin;
        this.item = item;
        // the variable below calculates the total ounces.
        int totalOz = numberOfItems * weightPerItemInOz;
        // the varibale increments divides the total ounces by ounces in 100 pounds to get the increment for the shipment. 
        double increments = Math.ceil(totalOz/1600.0);
        // this branch checks the orgin then sets the fee using increment variable and amount per 100 lbs based off origin. 
         if(origin.equals("Ankh-Morpork")) 
            this.fee = increments * 87;
        else if(origin.equals("Pseudopolis")) 
            this.fee = increments * 165;
        else if(origin.equals("Ueberwald")) 
            this.fee = increments * 997; 
        // this branch checks to see if the reciever is two certain locations and sets the fee to 0 because they dont have to pay a fee.     
        if(reciever.equals("Post Office") || reciever.equals("Patrician's Office"))
            this.fee = 0.0;
        // this branch checks if the shipment is harzadous then calculates the increase of the fee. 
        if(hazard.equals("yes")){
                this.hazardous = true;
                this.fee = this.fee * .65 + this.fee;
        } 
            else{
                   this.hazardous = false;
                }
                
    }

    /**
     * Below are getter methods for the class Delivery. All of the parameters are set within the main method with the test cases and these are used
     * for making the methods to use within the main method. 
     */
    // gets the reciever and returns the reciever as a string. 
    public String getReciever(){
        return reciever;
    }
    // gets the orgin and returns the origin as a string. 
    public String getOrigin(){
        return origin;
    }
    // gets the item type and returns the item as a string. 
    public String getItem(){
        return item;
    }
    // gets wether the shipment is hazardous or not and returns it as a boolean.
    public boolean getHazardous(){
        return hazardous;
    }
    // gets the fee and returns a double. 
    public double getFee(){
        return fee;
    }
}
