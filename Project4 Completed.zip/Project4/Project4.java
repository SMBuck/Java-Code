import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.Arrays;
/**
 * Project 4 used a main method createing a train array by using a readfile method. creates a printwriter to output a report that is created by the write report method to a file.
 * The Train class was created to create a Trian object for the main method array. 
 */
public class Project4 {
    //WHEN DID YOU FIRST START WORKING ON THIS ASSIGNMENT (date and time): <---------------
    //ANSWER: 10/14/2022 1736<---------------

    //DO NOT ALTER THE MAIN METHOD
    public static void main( String[] args ) {
        Train[] train = readFile( "departures.txt" );
        
        PrintWriter outStream = null;
        try { outStream = new PrintWriter( "arrivals.txt" ); }
        catch ( FileNotFoundException fnf ) { System.exit( -2 ); }
        
        //each trip will arive by the end of next day
        outStream.printf( "%d trains arriving today and tomorrow with total cargo %.2f lbs%n", train.length, Train.getWeightOfAllCargo() );
        writeReport(    0,  759, true, train, outStream );
        writeReport(  800, 1559, true, train, outStream );
        writeReport( 1600, 2359, true, train, outStream );
        
        writeReport(    0,  759, false, train, outStream );
        writeReport(  800, 1559, false, train, outStream );
        writeReport( 1600, 2359, false, train, outStream );
        
        outStream.close();
    }//DO NOT ALTER THE MAIN METHOD
    /**
     * @param - input file
     * takes an input file, reads from the file then puts the created Train objects into an array. 
     * @returns - Train array
     */
    public static Train[] readFile( String inputFileName ) {
        //IMPLEMENT THIS METHOD
        /**
         * the intention of this method is to take the input file, read through it, create a Train object then put each train created from that into an array. I intialized a few 
         * variables to make it a little simpler to understand while coding. I created a scanner and a new Train array and allocated the amount of space based on the first int in 
         * the file for number of trains. Then I used a while loop to iterate through the file moving from each value in the file until the cursor gets to the end. I then created a 
         * nested for loop to iterate for the amount of trains there were and saved the data to variables then created the Train object with the constructor and put that Train into
         * the array. I then used another nested for loop to take the next value in the file to iterate through the cargo that is on the train to save them to variables and then 
         * load them onto the train in the index accordingly. Then closed the file and returned the Train array. 
         */
        String filename = inputFileName;
        Scanner reader = null;
        try{
            File input = new File(filename);
            reader = new Scanner(input);
        }
        catch(FileNotFoundException e){
            System.out.print("File not found");
        }
        
        int numberOfTrains, departure, stops, duration, typesOfCargo, units;
        double weightPerItem;
        String route, details, cargoType;
        
        numberOfTrains = reader.nextInt();
        Train[] cargoTrains = new Train[numberOfTrains];
        
        while(reader.hasNext()){
            for(int i = 0; i < numberOfTrains; i++){
                route = reader.next();
                departure = reader.nextInt();
                stops = reader.nextInt();
                duration = reader.nextInt();
                typesOfCargo = reader.nextInt(); 
                Train t_i = new Train(route, departure, stops, duration);
                cargoTrains[i] = t_i;
                for(int k = 0; k < typesOfCargo; k++){
                    units = reader.nextInt();
                    weightPerItem = reader.nextDouble();
                    cargoType = reader.nextLine();
                    cargoTrains[i].loadCargo(cargoType, units, weightPerItem);
                }
            }
        }
        reader.close();
        return cargoTrains;
    }
    /**
     * @param - start time for shift, end time for shift, boolean today if the train arrived on the same day, a Train object from the array, the printwriter to write to the output file. 
     * @returns - void but prints a report to a file named arrivals.txt
     */  
    public static void writeReport( int start, int end, boolean today, Train[] t, PrintWriter out ) {
        //IMPLEMENT THIS METHOD
        /**
         * The goal of this method is to print a report for a 48 hour period of the trains arriving during each shift and the cargo onboard.
         * I used a branch statement to print out if it was arrving today or tommorrow based on the today paramter. Once the method is called it prints accordingly then
         * I use a for loop to iterate through the Train array and see if any of the trains arrived during that shift and if it was on the same day or the next day
         * If they do arrive in the 48 hours they are printed accordingly with their arrival time, departure time, the origin where it came from, the weight of the cargo and what 
         * and how many of the cargo there was. It then branches off to check if the weight was a certain amount to see how many crews were needed to unload the train. If there is a 
         * train the unload crews are printed and if there isnt a train then the is a print of no trains during that shift. 
         * 
         */
        String spaces = " ".repeat(9);
        String spaces2 = " ".repeat(3);
        int unloadCrew = 0, unloadingWeight;
        if(today == true)
        out.printf("%nArriving today %04d-%04d:%n", start, end);
        else{
            out.printf("%nArriving tommorrow %04d-%04d:%n", start,end);
        }
        for(int i = 0; i < t.length; i++){
            if(t[i].getArrivalTime() >= start && t[i].getArrivalTime() <= end && t[i].getSameDayArrival() == today){
                out.printf("%s%04d: The %04d train form %s:%n",spaces2,t[i].getArrivalTime(), t[i].getDepartureTime(), t[i].getOrigin());
                out.printf("%s%.2f lbs of %s%n",spaces,t[i].getWeightOfTrainCargo(),t[i].getCargo());
                if(t[i].getWeightOfTrainCargo() > 500.00){
                    unloadingWeight = (int)Math.ceil(t[i].getWeightOfTrainCargo() / 500);
                    unloadCrew = unloadingWeight;
                }
                else{
                    unloadCrew = 1;
                }
            }    
        }
        if(unloadCrew > 0)
        out.printf("Unloading crews needed: %d%n",unloadCrew);  
        else{
           out.printf("No trains.%n");
        }
    }
}
        
    

