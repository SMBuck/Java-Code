
/**
 * Class Train below creates a Train with the standard constructor initializing the values and the second constructor which build the train. The second constructor takes an orgin, 
 * departure, stops and duration and sets those variable accordingly with the help of the caluclateArrivalTimeMethod and LoadCargo Mehod. This class does not have setters, only getters 
 * because the arguments set all the variables once its passed to the Train. 
 *
 * @author (Marshall Buck)
 * @version (10/14/2022)
 */
public class Train
{
    /**
     * instance variables below for the Train class declared. 
     */ 
    private String origin,cargo;
    private int departureTime, arrivalTime;
    private boolean sameDayArrival;
    private double weightOfTrainCargo;
    private static double weightOfAllCargo;

    /**
     * Constructors for objects of class Train, this class has two constructors, one default to intialize the variables in the class and the second constructor takes a few parameters
     * to help build the Train object.
     */
    public Train()
    {
        // initialise instance variables
        this.origin = "";
        this.departureTime = 0;
        this.arrivalTime = 0;
        this.sameDayArrival = false;
        this.cargo = "";
        this.weightOfTrainCargo = 0.0;
        weightOfAllCargo ++;
    }
    /**
     * @ param - takes the origin, departure, stops, duration
     * sets the values using the parameters as well as using the calculateArrivalTimeMethod to help set the arrival time and uses the departure time and arrival time
     * to check and see if the train arrived on the same day or not. 
     *
     */
    public Train(String origin, int departure,int stops, int duration){
        
        this.origin = origin;
        this.departureTime = departure;
        calculateArrivalTime(stops,duration); 
        if((this.departureTime / 100 - 12) + (stops * 10 + duration) / 60 < 12 && this.arrivalTime != 0)
            this.sameDayArrival = true;
            else{
                this.sameDayArrival = false;
            }
    }
   

    /**
     * @param  takes stops and duration
     * uses these two variables to calculate the time for when the train is arriving. 
     * @return  is void just sets the arrivalTime variable. 
     */
    public void calculateArrivalTime(int stops, int duration){
        int timeDepart, timeDepartR, durationFirst, durationR, durationMil, arrivalMil, 
        combinedTotal, combined1, remainderMin, firstMin, checkValue, baseArrival;
        /**
         * the nested branch below first checks the departure time for a little different calculation for mins not hours. then takes the departure time and splits the time in half, one 
         * for hours and second for mins. It also multiplies the stops and adds it to the duration and splits the duration in half for hours/ mins. Then the mins are combined to see
         * if the sum is over 60 mins so it can split the hours/ min again. Then the hours are added together then the mins and then that number is checked based on the different cases to either reset
         * passed 2400 mil time change to 0 if at 2400 or stay the same. The final calculations end in Military time for output. 
         */
        if(this.departureTime > 60){
            timeDepart = (int)this.departureTime / 100;
            timeDepartR = this.departureTime % 100;
            durationFirst = (int)(stops * 10 + duration) / 60;
            durationR = (stops * 10 + duration) % 60;
            combined1 = timeDepartR + durationR;
            if (combined1 > 60){
                remainderMin = combined1 % 60;
                firstMin = (int)combined1 / 60;
                arrivalMil = (timeDepart + firstMin + durationFirst);
                baseArrival = (arrivalMil * 100 + remainderMin);
                if(baseArrival % 100 == 60 && baseArrival != 2360){
                    baseArrival += 40;
                    if(baseArrival > 2400){
                        baseArrival -= 2400;
                        this.arrivalTime = baseArrival;
                    }
                    else{
                        this.arrivalTime = baseArrival;
                    }
                }
                else if(baseArrival > 2400){
                    baseArrival -= 2400;
                    this.arrivalTime = baseArrival;
                }
                else if(baseArrival == 2360)
                    this.arrivalTime = 0;
                else{
                    this.arrivalTime = baseArrival;
                }
            }
            else{
                arrivalMil = (timeDepart + durationFirst);
                baseArrival = (arrivalMil * 100 + timeDepartR + durationR);
                if(baseArrival % 100 == 60 && baseArrival != 2360){
                    baseArrival += 40;
                    if(baseArrival > 2400){
                        baseArrival -= 2400;
                        this.arrivalTime = baseArrival;
                    } 
                    else{
                        this.arrivalTime = baseArrival;
                    }
                }
                else if(baseArrival > 2400){
                    baseArrival -= 2400;
                    this.arrivalTime = baseArrival;
                }
                else if(baseArrival == 2360)
                    this.arrivalTime = 0;
                else{
                    this.arrivalTime = baseArrival;
                }
            }
        }  
        else{
            timeDepart = this.departureTime;
            durationFirst = (int)(stops * 10 + duration) / 60;
            durationR = (stops * 10 + duration) % 60;
            combined1 = timeDepart + durationR;
            if(combined1 > 60){
                remainderMin = combined1 % 60;
                firstMin = (int)combined1 / 60;
                arrivalMil = (durationFirst + firstMin * 100);
                checkValue = (int)(timeDepart + arrivalMil)/60;
                if(checkValue % 2 == 0)//(departFirst + durationMil - 12);
                this.arrivalTime = arrivalMil + timeDepart + 40;
                else{
                    this.arrivalTime = arrivalMil + timeDepart;
                }
            }
            else{
                arrivalMil = (durationFirst * 100);
                baseArrival = arrivalMil + timeDepart + durationR;
                if(baseArrival % 100 == 60 && baseArrival != 2360){
                    baseArrival += 40;
                    if(baseArrival > 2400){
                        baseArrival -= 2400;
                        this.arrivalTime = baseArrival;
                    }
                    else{
                        this.arrivalTime = baseArrival;
                    }
                }
                else if(baseArrival > 2400){
                    baseArrival -= 2400;
                    this.arrivalTime = baseArrival;
                }
                else if(baseArrival == 2360)
                    this.arrivalTime = 0;
                else{
                    this.arrivalTime = baseArrival;
                }
            }
        }
    }
    /**
     * @ param - nothing
     * @ returns - string of the origin location. 
     */
    public String getOrigin(){
        return this.origin;
    }
    /**
     *  @ param - nothing
     *  @ returns - an int of the arrival time in Military time. 
     */
    public int getArrivalTime(){
        return this.arrivalTime;
    }
    /**
     * @param - nothing
     * @returns - an int of the departure time in Military time. 
     */
    public int getDepartureTime(){
        return this.departureTime;
    }
    /**
     * @param - nothing
     * @returns - a boolean on if the train arrived on the same day or not. 
     */
    public boolean getSameDayArrival(){
        return this.sameDayArrival;
    }
    /**
     * @param - nothing
     * @returns - a concatenated string of all the cargo loaded on the train. 
     */
    public String getCargo(){
        String sentence = (this.cargo.trim().replace("null",""));
        int position = sentence.lastIndexOf("and");
        this.cargo = sentence.substring(0,position);
        return this.cargo.trim(); 
    }
    /**
     * @param - nothing
     * @returns - a double of the weight of the train cargo when items are loaded. 
     */
    public double getWeightOfTrainCargo(){
        return this.weightOfTrainCargo;
    }
    /**
     * @param - nothing
     * @returns - a double of the weight of all cargo added up once all the trains are loaded up and departed within 48 hours. 
     */
    public static double getWeightOfAllCargo(){
        return weightOfAllCargo;
    }
    /**
     * @param - cargoType, units, weightPerItem
     * this method takes the parameters and creates a string to set the cargo value, it accumulates the weight of the trains and adds them up to get the weight of all the cargo. 
     * @returns - void
     */
    public void loadCargo(String cargoType,int units, double weightPerItem){
        String sentence = units + " " + cargoType + " and ";
        this.cargo += sentence;
        this.weightOfTrainCargo += units * weightPerItem;
        weightOfAllCargo += this.weightOfTrainCargo;
    }
}
