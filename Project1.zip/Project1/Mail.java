
/**
 * The class Mail has 4 instance variables and a few getters and setters so you can access this class from the outside in the main object
 * and the user can input and change values so it will remain giving accurate output to the user depending on the values inputed. 
 * @author (Marshall Buck)
 * @version (09/06/2022)
 */
public class Mail{
    // instance variables - declaring the type for the instance variables. 
    private String type;
    private String destination;
    private int units;
    private double postagePerUnit;

    /**
     * Constructor for objects of class Mail
     */
    
    public Mail(){
        // initialise instance variables to standard amounts so they can be changed based on the inputs from the user. 
        this.type = "";
        this.destination = "";
        this.units = 0;
        this.postagePerUnit = 0.0;
    }

    /**
     * These are the getters and setter for the class Mail. You can use these now to change some of the private instance variables from outside
     * the class.
     */
    public void setDestination(String destination){
        this.destination = destination; // this sets the destination of the class to the user input. 
    }
    public void setUnits(int howMany){
        this.units = howMany;  // this sets the amount of the mail the user inputs. 
    }
    public void setPostagePerUnit(double stamps){
        this.postagePerUnit = stamps; // this sets the amount for each type of mail the user inputs. 
    }
    public void setType (String typeMail){
        this.type = typeMail; // this sets the type of mail that the user inputs. 
    }
    public String getDestination(){
        return destination;  // returns the destination the user inputs.
    }
    public int getUnits(){
        return units;  // returns the amount of mail the user inputs. 
    }
    public double getPostagePerUnit(){
        return postagePerUnit;  // returns the cost for each item the user is shipping. 
    }
    public String getType(){
        return type;  // returns the type of mail the user is shipping. 
    }
}
