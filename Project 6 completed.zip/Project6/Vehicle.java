
/**
 * Abstract class Vehicle is the parent class to Boat, Train, Coach. It has two constructors that are chained by the sub classes
 * and each method can be accessed by each subclass. 
 *
 * @author (Marshall Buck)
 * @version (11/13/2022)
 */
public abstract class Vehicle
{
    private String destination;
    private double income;
    private static double revenue = 0.0;
    /**
     * Standard constructor initiated.
     */
    protected Vehicle(){
        this("",0.0);
    }
    /**
     * @param: destination,income
     * Second constructor set for the parent Vehicle class and is chained in the derived class. 
     * @return: none
     */
    protected Vehicle(String destination, double income){
        this.destination = destination;
        this.income = income;
    }
    /**
     * @param: none
     * @return: the destination as a string
     */
    public String getDestination(){
        return this.destination;
    }
    /**
     * @param: none
     * @return: the income as a double
     */
    public double getIncome(){
        return this.income;
    }
    /**
     * @param: takes a double and accumulates it to the revenue. 
     * @return: void
     */
    public static void setRevenue(double addRevenue){
        revenue += addRevenue;
    }
    /**
     * @param: none
     * @return: revenue
     */
    public static double getRevenue(){
        return revenue;
    }
    /**
     * The next two methods are abstract methods and are going to be overidden in the derived classes to be used and invoked with them. One is void and the other returns
     * a double of the caluclated profit for the transport.
     */
    public abstract void addToTotalProfit();
    public abstract double calculateVehicleProfit();
}
