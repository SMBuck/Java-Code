
/**
 * Derived from the Vehicle class this is the Coach class that has horses and a crew and uses the overidden methods in the abstract parent class. 
 *
 * @author (Marshall Buck)
 * @version (11/13/2022)
 */
public class Coach extends Vehicle
{
    private int horse, crew;
    /**
     * Standard Constructor initializing variables
     */
    public Coach()
    {
        // initialise instance variables
        this("",0.0,0.0);
        this.horse = 0;
        this.crew = 0;
    }
    /**
     * @param: destination, weight, income
     * chains the parent constructor to take in destination and income, checks the weight of the shipment and caluclates how many horses and crew are needed for the
     * shipment. 
     */
    public Coach(String destination, double weight, double income){
        super(destination, income);
        if(weight < 100){
            this.horse = 1;
            this.crew = 1;
        }
        else if(weight >= 100){
            this.horse = (int)Math.ceil(weight/ 100);
            if(this.horse > 4){
                this.crew = 2;
            }
            else{
                this.crew = 1;
            }
        }
    }
    /**
     * @param: none
     * @return: an int of horses used for the shipment. 
     */
    public int getHorses(){
        return this.horse;
    }
    /**
     * @param: none
     * @return: an int of crew used for the shipment. 
     */
    public int getCrew(){
        return this.crew;
    }
    /**
     * @param: none
     * overidden from the parent class and is used to call the caluclate profit method and then add the profit to the revuneue to accumlate the total profit. 
     * @return: void
     */
    @Override
    public void addToTotalProfit(){
        super.setRevenue(calculateVehicleProfit());
    }
    /**
     * @param: none
     * checks the destination of the shipment then based off base price and price per crew and horses based on the type of transport, it takes the income of the 
     * shipment and caluclates the cost of the shipment and then calculates the profit of the entire shipment. 
     * @return: a double of the profit made + or -.
     */
    @Override
    public double calculateVehicleProfit(){
        double profit = 0.0;
        switch(super.getDestination()){
            case "Lancre":
                profit = super.getIncome();
                profit = profit - (200 + (this.crew * 50) + (this.horse * 30));
                break;
            case "Ueberwald":
                profit = super.getIncome();
                profit = profit - (200 + (this.crew * 150) + (this.horse * 100));
                break;
            case "Borogravia":
                profit = super.getIncome();
                profit = profit - (200 + (this.crew * 150) + (this.horse * 100));
                break;
            case "Klatch":
                profit = super.getIncome();
                profit = profit - (200 + (this.crew * 60) + (this.horse * 50));
                break;
        }
        return profit;
    }
}
