
/**
 * Derived class from the Vehcile class, It is a type of transport for shipments that involves a crew for the amount of weight of the shipment. 
 *
 * @author (Marshall Buck)
 * @version (11/13/2022)
 */
public class Boat extends Vehicle
{
    private int crew;
    /**
     * Standard constructor for class Boat initializing variables
     */
    public Boat()
    {
        this("",0.0,0.0);
        this.crew = 0;
    }
    /**
     * @param: destination, weight, income
     * chains the parent constructor and takes the weight of the shipment and caluclates how many crew memebers are needed for the shipment. 
     */
    public Boat(String destination, double weight, double income){
        super(destination, income);
        if(weight < 500){
            this.crew = 1;
        }
        else{
            this.crew = (int)Math.ceil(weight / 500.00);
        }
    }
    /**
     * @param: none
     * @return: an int of how many crew members are needed. 
     */
    public int getCrew(){
        return this.crew;
    }
    /**
     * @param: none
     * overidden from the parent class and is used to call the caluclate profit method and then add the profit to the revuneue to accumlate the total profit. 
     * @return: void
     */
    @Override
    public void addToTotalProfit(){
        super.setRevenue(calculateVehicleProfit());    
    }
    /**
     * @param: none
     * checks the destination of the shipment then based off base price and price per crew and horses based on the type of transport, it takes the income of the 
     * shipment and caluclates the cost of the shipment and then calculates the profit of the entire shipment. 
     * @return: a double of the profit made + or -.
     */
    @Override
    public double calculateVehicleProfit(){
        double profit = 0.0;
        switch(super.getDestination()){
            case "Lancre":
                profit = super.getIncome() - (1000 + (this.crew * 50));
                break;
            case "Ueberwald":
                profit = super.getIncome() - (3000 + (this.crew * 150));
                break;
            case "Borogravia":
                profit = super.getIncome() - (3000 + (this.crew * 150));
                break;
            case "Klatch":
                profit = super.getIncome() - (1200 + (this.crew * 60));
                break;
        }
        return profit;
    }
}
