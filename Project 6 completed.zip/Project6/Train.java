
/**
 * Class Train is a derived class of Vehicle. It holds two constructors and uses the variable cars to see how many are needed for the shipment. 
 *
 * @author (Marshall Buck)
 * @version (11/13/2022)
 */
public class Train extends Vehicle
{
    private int cars;
    /**
     * Standard Constructor for Class Train
     */
    public Train()
    {
        // initialise instance variables
        this("", 0, 0.0);
        this.cars = 0;
    }
    /**
     * @param: destination, cars, income
     * chains the parent class constructor and sets the number of cars needed for the shipment. 
     */
    public Train(String destination, int cars, double income){
        super(destination, income);
        this.cars = cars;
    }
    /**
     * @param: none
     * @return: int of cars needed for the shipment. 
     */
    public int getCars(){
        return this.cars;
    }
    /**
     * * @param: none
     * overidden from the parent class and is used to call the caluclate profit method and then add the profit to the revuneue to accumlate the total profit. 
     * @return: void
     */
    @Override
    public void addToTotalProfit(){
        super.setRevenue(calculateVehicleProfit());
    }
    /**
     * @param: none
     * checks the destination of the shipment then based off base price and price per crew and horses based on the type of transport, it takes the income of the 
     * shipment and caluclates the cost of the shipment and then calculates the profit of the entire shipment. 
     * @return: a double of the profit made + or -.
     */
    @Override
    public double calculateVehicleProfit(){
        double profit = 0.0;
        switch(super.getDestination()){
            case "Lancre":
                profit = super.getIncome() - (600 + (this.cars * 100));
                break;
            case "Ueberwald":
                profit = super.getIncome() - (4000 + (this.cars * 100));
                break;
            case "Borogravia":
                profit = super.getIncome() - (4000 + (this.cars* 100));
                break;
            case "Klatch":
                profit = super.getIncome() - (2100 + (this.cars * 100));
                break;
        }
        return profit;
    }
}
