import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.io.File;

public class Project6 {
    //DATE AND TIME YOU FIRST START WORKING ON THIS ASSIGNMENT (date AND time): <--------------------
    //ANSWER:    11/13/2022  1700  <--------------------
    
    //DO NOT ALTER THE MAIN METHOD
    public static void main( String[] args ) throws FileNotFoundException {
        //input stream
        Scanner in = new Scanner( new File( "info1.txt" ) );
        
        //read the input file and populate the array list
        ArrayList< Vehicle > allUnsorted = readData( in );
        
        //output for half credit
        printVehicles( allUnsorted );
        
        //sort the array list by destination 
        //1. Lancre, 2. Ueberwald, 3. Borogravia, 4. Klatch
        //and for each destination 1. boats, 2. trains, 3. coaches
        ArrayList< Vehicle > allSorted = sortVehicles( allUnsorted );
        
        //output for half credit
        printVehicles( allSorted );
        
        //print revenue
        System.out.printf( "Today's Ankh-Morpork Post Office Profit:  $%,10.2f%n%n", Vehicle.getRevenue() );
    } //DO NOT ALTER THE MAIN METHOD
    /**
     * @ param: takes the scanner object that scans throught the input file.
     * Loops throught the file using the scanner grabs the type of vehicle, instantiates that vehicle the adds the total profit after using the abstract method from the 
     * partent class. 
     * @returns: ArrayList of Vehicles that are unsorted. 
     */
    public static ArrayList< Vehicle > readData( Scanner in ) {
        /**
         * I initialize a few variables to hold values from the input file. I then use a while loop to iterate through that file and check based on the type of vehicle
         * it is. I then save the values needed for each constructor chained from the abstract parent class to instaniate the object. Then I use the overidden method to
         * add to the vehicles profit. Then once the loop is over it returns the ArrayList of all the vehicles created from the input file. 
         */
        ArrayList< Vehicle > unsorted = new ArrayList<>();
        String destination, transport;
        double weight, income, profit;
        int cars;
        while(in.hasNextLine()){
            destination = in.next();
            transport = in.next();
            if(transport.equals("boat")){
                weight = in.nextDouble();
                income = in.nextDouble();
                Boat b = new Boat(destination, weight, income);
                unsorted.add(b);
                b.addToTotalProfit();
            }
            else if(transport.equals("coach")){
                weight = in.nextDouble();
                income = in.nextDouble();
                Coach c = new Coach(destination, weight, income);
                unsorted.add(c);
                c.addToTotalProfit(); 
            }
            else if(transport.equals("train")){
                cars = in.nextInt();
                income = in.nextDouble();
                Train t = new Train(destination, cars, income);
                unsorted.add(t);
                t.addToTotalProfit();
            }
        }
        return unsorted;
    }
    
    /**
     * @param: ArrayList of unsorted vehicles
     * sorts through the ArrayList, orders the vehicles based on the destination, then orders the type of vehicle for each destination.
     * @returns: ArrayList of sorted vehicles
     */
    public static ArrayList< Vehicle > sortVehicles( ArrayList< Vehicle > unsorted ) {
        /**
         * I created a few ArrayList for each destination and one temp ArrayList to just hold onto a vehicle when needed. I then use the first for loop to iterate
         * through the unsorted list and organized the vehicles based on destination and then add them to each respective ArrayList.
         */
        
        ArrayList< Vehicle > sorted = new ArrayList<>();
        ArrayList< Vehicle > temp = new ArrayList<>(2);
        ArrayList< Vehicle > lancre = new ArrayList<>();
        ArrayList< Vehicle > ueberwald = new ArrayList<>();
        ArrayList< Vehicle > borogravia = new ArrayList<>();
        ArrayList< Vehicle > klatch = new ArrayList<>();
       
        for(int i = 0; i < unsorted.size(); i ++){
            if(unsorted.get(i).getDestination().equals("Lancre")){
                lancre.add(unsorted.get(i));
            }
            else if(unsorted.get(i).getDestination().equals("Ueberwald")){
                ueberwald.add(unsorted.get(i));
            }
            else if(unsorted.get(i).getDestination().equals("Borogravia")){
                borogravia.add(unsorted.get(i));
            }
            else if(unsorted.get(i).getDestination().equals("Klatch")){
                klatch.add(unsorted.get(i));
            }
        }
        /**
         * The next 4 loops take each destination ArrayList and sorts through them comparing the type of transport and then organizes each list based on the transport
         * then after the loop runs it adds the ordered vehicles into the sorted ArrayList, then at the end it returns the fully sorted ArrayList. 
         */
        for(int j = 0; j < lancre.size(); j++){
            if(j < lancre.size() - 1){
                if(lancre.get(j) instanceof Coach && lancre.get(j+1) instanceof Train){
                    temp.add(0,lancre.get(j+1));
                    temp.add(1,lancre.get(j));
                    lancre.set(j, temp.get(0));
                    lancre.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(lancre.get(j) instanceof Coach && lancre.get(j+1) instanceof Boat){
                    temp.add(0,lancre.get(j+1));
                    temp.add(1,lancre.get(j));
                    lancre.set(j, temp.get(0));
                    lancre.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(lancre.get(j) instanceof Boat && lancre.get(j+1) instanceof Train){
                    temp.add(0, lancre.get(j+1));
                    temp.add(1, lancre.get(j));
                    lancre.set(j, temp.get(0));
                    lancre.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
            }
        }
        sorted.addAll(lancre);
        for(int j = 0; j < ueberwald.size(); j++){
            if(j < ueberwald.size() - 1){
                if(ueberwald.get(j) instanceof Coach && ueberwald.get(j+1) instanceof Train){
                    temp.add(0,ueberwald.get(j+1));
                    temp.add(1,ueberwald.get(j));
                    ueberwald.set(j, temp.get(0));
                    ueberwald.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(ueberwald.get(j) instanceof Coach && ueberwald.get(j+1) instanceof Boat){
                    temp.add(0,ueberwald.get(j+1));
                    temp.add(1,ueberwald.get(j));
                    ueberwald.set(j, temp.get(0));
                    ueberwald.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(ueberwald.get(j) instanceof Boat && ueberwald.get(j+1) instanceof Train){
                    temp.add(0, ueberwald.get(j+1));
                    temp.add(1, ueberwald.get(j));
                    ueberwald.set(j, temp.get(0));
                    ueberwald.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
            }
        }
        sorted.addAll(ueberwald);
        for(int j = 0; j < borogravia.size(); j++){
            if(j < borogravia.size() - 1){
                if(borogravia.get(j) instanceof Coach && borogravia.get(j+1) instanceof Train){
                    temp.add(0,borogravia.get(j+1));
                    temp.add(1,borogravia.get(j));
                    borogravia.set(j, temp.get(0));
                    borogravia.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(borogravia.get(j) instanceof Coach && borogravia.get(j+1) instanceof Boat){
                    temp.add(0,borogravia.get(j+1));
                    temp.add(1,borogravia.get(j));
                    borogravia.set(j, temp.get(0));
                    borogravia.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(borogravia.get(j) instanceof Boat && borogravia.get(j+1) instanceof Train){
                    temp.add(0, borogravia.get(j+1));
                    temp.add(1, borogravia.get(j));
                    borogravia.set(j, temp.get(0));
                    borogravia.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
            }
        }
        sorted.addAll(borogravia);
        for(int j = 0; j < klatch.size(); j++){
            if(j < klatch.size() - 1){
                if(klatch.get(j) instanceof Coach && klatch.get(j+1) instanceof Train){
                    temp.add(0,klatch.get(j+1));
                    temp.add(1,klatch.get(j));
                    klatch.set(j, temp.get(0));
                    klatch.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(klatch.get(j) instanceof Coach && klatch.get(j+1) instanceof Boat){
                    temp.add(0,klatch.get(j+1));
                    temp.add(1,klatch.get(j));
                    klatch.set(j, temp.get(0));
                    klatch.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
                else if(klatch.get(j) instanceof Boat && klatch.get(j+1) instanceof Train){
                    temp.add(0, klatch.get(j+1));
                    temp.add(1, klatch.get(j));
                    klatch.set(j, temp.get(0));
                    klatch.set(j+1, temp.get(1));
                    temp.remove(0);
                    temp.remove(0);
                }
            }
        }
        sorted.addAll(klatch);
        return sorted;
    }
    /**
     * @param: an ArrayList of vehicles
     * takes that ArrayList and prints information based of the instance of which vehicle it is. 
     * @return: void
     */
    public static void printVehicles( ArrayList< Vehicle > v ) {
        /**
         * The for loop iterates throught the ArrayList and checks which type of vehicle it is. Once one checks true it then grabs the profit from the vehicle and checks
         * if its a profit or a loss and prints the information accordingly. 
         */
        System.out.println("Ankh-Morpork Post Office mail dispatches:"); 
        for ( Vehicle vehicle : v ) {
            if( vehicle instanceof Boat ) {
                double profit = vehicle.calculateVehicleProfit();
                //System.out.println( "Boat  to " + vehicle.getDestination() );
                System.out.printf("Boat  to %10s ( %2d %s)",vehicle.getDestination(),((Boat)vehicle).getCrew(),"crew");
                if(profit > 0){
                    System.out.printf("%10s: $ %,9.2f%n","PROFIT", profit);
                }
                else{
                    System.out.printf("%10s: $ %,9.2f%n","LOSS", Math.abs(profit));
                }
            }
            else if( vehicle instanceof Train ) {
                double profit = vehicle.calculateVehicleProfit();
                //System.out.println( "Train to " + vehicle.getDestination() );
                System.out.printf("Train to %10s ( %2d %s)",vehicle.getDestination(),((Train)vehicle).getCars(),"cars");
                if(profit > 0){
                    System.out.printf("%10s: $ %,9.2f%n","PROFIT", profit);
                }
                else{
                    System.out.printf("%10s: $ %,9.2f%n","LOSS", Math.abs(profit));
                }
            }
            else {
                double profit = vehicle.calculateVehicleProfit();
                //System.out.println( "Coach to " + vehicle.getDestination() );
                System.out.printf("Coach to %10s ( %2d %s)",vehicle.getDestination(),((Coach)vehicle).getHorses(),"horses");
                if(profit > 0){
                    System.out.printf("%8s: $ %,9.2f%n","PROFIT", profit);
                }
                else{
                    System.out.printf("%8s: $ %,9.2f%n","LOSS", Math.abs(profit));
                }
            }
        }
        System.out.println();
    }
}
