
/**
 * This is a class MailCoach, it sets a few instance variables used in the main
 * to be delivered using the MailCoach, sets these variables to standard constructor to base values, sets two 
 * of the variables in the second constructor taken from the main and also has getters and setters to use inputs from 
 * the user in the main.
 * .
 *
 * @author (Marshall Buck)
 * @version (10/3/2022)
 */
public class MailCoach
{
    /* instance variables*/
    private String route;
    private int capacity,letters,packages;
    private boolean dispatched;

    /**
     * Constructors for objects of class MailCoach
     * @param nothing
     * @return nothing
     */
    public MailCoach()
    {
        /* initialise instance variables*/
        this.route = "";
        this.capacity = 0;
        this.letters = 0;
        this.packages = 0;
        this.dispatched = false;
    }
    /**
     * @param The second constructor is used int the main to create the MailCoach object with the route and total capacity the route can take. 
     * @returns nothing.
     */
    public MailCoach(String route, int capacity)
    {
        /* instance variables utilized for secondary constructor with values*/
        this.route = route;
        this.letters = letters;
        this.packages = packages;
        this.dispatched = false;
        this.capacity = capacity;  
    }

    /**
     * listed below are getters and setters for the MailCoach class to be used in the main. 
     */ 
     
    /** @param  no parameter
     * @return  returns the route of where the user is wanting to send the letters or packages. 
     */
    public String getRoute(){
        return this.route;
    }
    /** param no parameter
     * return returns the capacity left on the mail coach after the letters and packages have been loaded. 
     */
    public int getCapacity(){
        return this.capacity;
    }
    /** @param no parameter
     * @return returns the letters loaded onto the mail coach
     */
    public int getLetters(){
        return this.letters;
    }
    /** @param no parameter
     * @return returns the packages loaded onto the mail coach
     */
    public int getPackages(){
        return this.packages;
    }
    /** @param no parameter
     * @return dispatched boolean true or false.
     */
    public boolean getDispatched(){
        return this.dispatched;
    }
    /** @param takes an int of letters to be loaded, calculates if the amount of letters requested to be loaded can be, updates the capacity and letters
     * loaded and dispatches the Mailcoach if the capacity runs out. 
     * @return  letters not loaded or 0 if they amount of letters can be loaded. 
     */
    public int setLetters(int lettersToLoad){
        int notLoaded;
        this.capacity = capacity - lettersToLoad;
        this.letters = letters + lettersToLoad;
        if(this.capacity <= 0){
           this.dispatched = true; 
           this.letters = letters - Math.abs(capacity);
           notLoaded = Math.abs(capacity); 
           this.capacity = 0;
           return notLoaded;
        }    
        else{
            return 0;
        }
    }
    
    /** @param takes an int of packages to be loaded, calulates the amount to see if they can fit on the mailcoach based on the capacity. if all the 
     * packages can be loaded it updates the capacity and packages and it returns a value. if some of the packages cant be loaded it updates the capacity
     * and packages and returns a value. It will dispatch the MailCoach if the capacity is reached.  
     * @return packages not loaded based on the amount of capacity to package calculation or if all items can be loaded returns 0
     */
    public int setPackages(int packagesToLoad){
        int notLoaded, modder, count, loaded, multiplier;
        count = capacity;
        this.capacity = capacity - (packagesToLoad * 20);
        this.packages = packages + packagesToLoad;
        if(this.capacity <= 0){
            loaded = count / 20;
            notLoaded = packagesToLoad - loaded;
            multiplier = loaded * 20;
            this.packages = packages - notLoaded;
            this.capacity = count - multiplier;
            if(this.capacity == 0)
                this.dispatched = true;
            return notLoaded;
        }
        else{
            return 0;
        }
    }    
}

    
