import java.util.Scanner;
public class Project3 {
    //DATE AND TIME YOU FIRST START WORKING ON THIS ASSIGNMENT (date AND time): <--------------------
    //ANSWER: (10/03/2022 1201 a.m.)               <--------------------
    
    //DO NOT ALTER THE MAIN METHOD
    public static void main( String[] args ) {
        //use this method to test your entity class, comment it out when you've passed all tests
        testEntityClass();
        
        MailCoach stolat = new MailCoach( "Stolat", 1200 );
        MailCoach borogravia = new MailCoach( "Borogravia", 750 );
        MailCoach quirm = new MailCoach( "Quirm", 366 );
        
        System.out.println( "Welcome to the Ankh-Morpork Post Office new routes mail coach dispatch!" );
        //print the initial menu
        printMenu( stolat, borogravia, quirm );
        //call go and load up as much mail as is possible
        go( stolat, borogravia, quirm );
        //print report when all mail coaches have been dispatched
        printReport( stolat, borogravia, quirm );
    } //DO NOT ALTER THE MAIN METHOD
    
    //DO NOT ALTER THE testEntityClass METHOD
    public static void testEntityClass() {
        MailCoach test1 = new MailCoach();
        
        assert test1.getRoute().equals( "" ) && 
                test1.getCapacity() + test1.getLetters() + test1.getPackages() == 0  && 
                !test1.getDispatched() : "standard constructor fail";
        
        MailCoach test2 = new MailCoach( "City", 134 );
        assert test2.getRoute().equals( "City" ) : "second constructor instance variable route not properly set";
        assert test2.getLetters() + test2.getPackages() == 0 : "second constructor instance variables letters and/or packages not properly set";
        assert test2.getCapacity() == 134 : "second constructor instance variables capacity not properly set";
        assert !test2.getDispatched() : "second constructor instance variables dispatched not properly set";
        
        assert test2.setLetters( 20 ) == 0 : "setLetters not correct return value";
        assert test2.getLetters() == 20 : "setLetters not correct updating letters loaded";
        assert test2.getCapacity() == 114 : "setLetters not correct updating capacity";
        assert test2.setLetters( 150 ) == 36 : "setLetters not correct return value";
        assert test2.getLetters() == 134 : "setLetters not correct updating letters loaded";
        assert test2.getCapacity() == 0 : "setLetters not correct updating capacity";
        assert test2.getDispatched() : "setLetters not correct updating dispatch status";
        
        MailCoach test3 = new MailCoach( "City", 134 );
        assert test3.setPackages( 2 ) == 0 : "setPackages not correct return value";
        assert test3.getPackages() == 2 : "setPackages not correct updating letters loaded";
        assert test3.getCapacity() == 94 : "setPackages not correct updating capacity";
        assert test3.setPackages( 10 ) == 6 : "setPackages not correct return value";
        assert test3.getPackages() == 6 : "setPackages not correct updating letters loaded";
        assert test3.getCapacity() == 14 : "setPackages not correct updating capacity";
        assert test3.setLetters( 15 ) == 1 : "setLetters not correct return value";
        assert test3.getCapacity() == 0 : "setPackages not correct updating capacity";
        assert test3.getDispatched() : "setPackages not correct updating dispatch status";
        
        System.out.print( "MailCoach class all tests passed.\n" );        
    } //DO NOT ALTER THE testEntityClass METHOD
    
    /**
     * @param takes 3 of the MailCoach objects, uses a while loop to loop through the inputs from the user based on destination, then calls the
     * loadUp method to output what was loaded for the user depending on if the mail coach was dispatched or not. if the mail coach has been dispatched
     * it lets the user know accordingly then once all the capacity has been reached the loop stops. 
     */
    public static void go( MailCoach stolat, MailCoach borogravia, MailCoach quirm ) {     
        //IMPLEMENT THIS METHOD
        Scanner myScanner = new Scanner(System.in);
        String destination, type;
        int capacity1, capacity2, capacity3, totalCapacity, quantity;
    
        capacity1 = stolat.getCapacity();
        capacity2 = borogravia.getCapacity();
        capacity3 = quirm.getCapacity();
        
        totalCapacity = capacity1 + capacity2 + capacity3;
        
        
        while(totalCapacity > 0){
            System.out.print("What is the destination? ");
            destination = myScanner.nextLine().toLowerCase().trim();
            switch(destination){
                case"stolat":
                    if(stolat.getDispatched() == true){
                        System.out.printf("The mail coach to Stolat has been dispatched. Try again tomorrow.%n%n");
                        printMenu(stolat,borogravia,quirm);
                    }
                        else{
                            System.out.print("What are you shipping to Stolat? ");
                            quantity = myScanner.nextInt();
                            type = myScanner.next().toLowerCase().trim();
                            loadUp(stolat,type,quantity);
                            printMenu(stolat,borogravia,quirm);
                        }
                    capacity1 = stolat.getCapacity();
                    break;
                case"1":
                    if(stolat.getDispatched() == true){
                        System.out.printf("The mail coach to Stolat has been dispatched. Try again tomorrow.%n%n");
                        printMenu(stolat,borogravia,quirm);
                    }
                        else{
                            System.out.print("What are you shipping to Stolat? ");
                            quantity = myScanner.nextInt();
                            type = myScanner.next().toLowerCase().trim();
                            loadUp(stolat,type,quantity);
                            printMenu(stolat,borogravia,quirm);
                        }
                    capacity1 = stolat.getCapacity();
                    break;
                case"borogravia":
                    if(borogravia.getDispatched() == true){
                        System.out.printf("The mail coach to Borogravia has been dispatched. Try again tomorrow.%n%n");
                        printMenu(stolat,borogravia,quirm);
                    }
                        else{
                            System.out.print("What are you shipping to Borogravia? ");
                            quantity = myScanner.nextInt();
                            type = myScanner.next().toLowerCase().trim();
                            loadUp(borogravia,type,quantity);
                            printMenu(stolat,borogravia,quirm);
                        }
                    capacity2 = borogravia.getCapacity();
                    break;
                case"2":
                    if(borogravia.getDispatched() == true){
                        System.out.printf("The mail coach to Borogravia has been dispatched. Try again tomorrow.%n%n");
                        printMenu(stolat,borogravia,quirm);
                    }
                        else{
                            System.out.print("What are you shipping to Borogravia? ");
                            quantity = myScanner.nextInt();
                            type = myScanner.next().toLowerCase().trim();
                            loadUp(borogravia,type,quantity);
                            printMenu(stolat,borogravia,quirm);
                        }
                    capacity2 = borogravia.getCapacity();
                    break;
                case"quirm":
                    if(quirm.getDispatched() == true){
                        System.out.printf("The mail coach to Quirm has been dispatched. Try again tomorrow.%n%n");
                        printMenu(stolat,borogravia,quirm);
                    }
                        else{
                            System.out.print("What are you shipping to Quirm? ");
                            quantity = myScanner.nextInt();
                            type = myScanner.next().toLowerCase().trim();
                            loadUp(quirm,type,quantity);
                            printMenu(stolat,borogravia,quirm);
                        }
                    capacity3 = quirm.getCapacity();
                    break;
                case"3":
                    if(quirm.getDispatched() == true){
                        System.out.printf("The mail coach to Quirm has been dispatched. Try again tomorrow.%n%n");
                        printMenu(stolat,borogravia,quirm);
                    }
                        else{
                            System.out.print("What are you shipping to Quirm? ");
                            quantity = myScanner.nextInt();
                            type = myScanner.next().toLowerCase().trim();
                            loadUp(quirm,type,quantity);
                            printMenu(stolat,borogravia,quirm);
                        }
                    capacity3 = quirm.getCapacity();
                    break;
                    
            }
            totalCapacity = capacity1 + capacity2 + capacity3;
        }
    }
    
    /**
     * This method prints the menu for the mail coach.
     * @param takes 3 of the MailCoach objects and prints the menu to the screen for the user to look at showing remaining capacity, 3 locations, and if 
     * the MailCoach has been dispatched. 
     */
    
    public static void printMenu( MailCoach stolat, MailCoach borogravia, MailCoach quirm ) {
        //IMPLEMENT THIS METHOD 
        System.out.println("Remaining mail coach capacity:");
        if(stolat.getDispatched() == true)
            System.out.printf("   Stolat - dispatched%n");
            else{
                System.out.printf("   1. Stolat: remaining capacity %d%n",stolat.getCapacity());
            }
        if(borogravia.getDispatched() == true)
            System.out.printf("   Borogravia - dispatched%n");
            else{
                System.out.printf("   2. Borogravia: remaining capacity %d%n",borogravia.getCapacity());
            }
        if(quirm.getDispatched() == true)
            System.out.printf("   Quirm - dispatched%n");
            else{
                System.out.printf("   3. Quirm: remaining capacity %d%n",quirm.getCapacity());
            }
        }
    
    /**
     * @param takes 1 MailCoach object, a string of the type of item to be loaded, and the quantity of the item the user wants to load.
     * Then prints if the amount of items can be loaded onto the mail coach if there is enough capacity. If the capacity cant withold the amount of items
     * it lets the user know how many items couldnt be loaded out of what they requested. If the amount of items is not valid it also will let the user 
     * know. 
     */
    public static void loadUp( MailCoach d, String type, int quantity ) {
        //IMPLEMENT THIS METHOD 
        switch(type){
            case"letter":
                int overLoadLetters, overLoadPackages;
                if(quantity > 0){
                    overLoadLetters = d.setLetters(quantity);  
                    if(overLoadLetters == 0)
                        System.out.printf("Your " + quantity + " %ss have been loaded for delivery.%n%n",type);
                    else{
                        System.out.printf("%d of your %d %ss couldn't be dispatched today, bring them back tomorrow.%n%n",overLoadLetters, quantity, type);
                    }
                }
                else{
                    System.out.printf("This is not a valid amount. Back of the line!%n%n");
                }
                break;
            case"letters":
                if(quantity > 0){
                    overLoadLetters = d.setLetters(quantity);
                    if(overLoadLetters == 0)
                        System.out.printf("Your " + quantity + " %s have been loaded for delivery.%n%n",type);
                    else{
                        System.out.printf("%d of your %d %ss couldn't be dispatched today, bring them back tomorrow.%n%n",overLoadLetters, quantity, type);
                    }
                }
                else{
                    System.out.printf("This is not a valid amount. Back of the line!%n%n");
                }
                break;
            case"package":
                if(quantity >0){
                    overLoadPackages = d.setPackages(quantity);
                    if(overLoadPackages == 0)
                        System.out.printf("Your " + quantity + " %ss have been loaded for delivery.%n%n",type);
                    else{
                        System.out.printf("%d of your %d %ss couldn't be dispatched today, bring them back tomorrow.%n%n",overLoadPackages, quantity, type);
                    }
                }
                else{
                    System.out.printf("This is not a valid amount. Back of the line!%n%n");
                }
                break;
            case"packages":
                if(quantity > 0){
                    overLoadPackages = d.setPackages(quantity);
                    if(overLoadPackages == 0)
                        System.out.printf("Your " + quantity + " %s have been loaded for delivery.%n%n",type);
                    else{
                        System.out.printf("%d of your %d %ss couldn't be dispatched today, bring them back tomorrow.%n%n",overLoadPackages, quantity, type);
                    }
                }
                else{
                    System.out.printf("This is not a valid amount. Back of the line!%n%n");
                }
                break;
            default:
                System.out.printf("We dont't ship %s. Back of the line!%n%n",type);
            }       
    }
    
    /**
     * @param takes the 3 MailCoach objects, obtains if they have been dispatched and when they all have been dispatched it prints a report for the user
     * showing the amount of which type of items were loaded to each route. 
     */
    public static void printReport( MailCoach stolat, MailCoach borogravia, MailCoach quirm ) {
        //IMPLEMENT THIS METHOD 
        boolean route1, route2, route3;
        route1 = stolat.getDispatched();
        route2 = borogravia.getDispatched();
        route3 = quirm.getDispatched();
        
        if(route1 == true && route2 == true && route3 == true){
            System.out.println("All mail coaches have been dispatched for the day.");
            System.out.printf("Dispatched: mail coach to Stolat %5s %4d %7s, %3d %8s%n","-", stolat.getLetters(),"letters",stolat.getPackages(),"packages");
            System.out.printf("Dispatched: mail coach to Borogravia %1s %4d %7s, %3d %8s%n","-", borogravia.getLetters(),"letters", borogravia.getPackages(),"packages");
            System.out.printf("Dispatched: mail coach to Quirm %6s %4d %7s, %3d %8s%n%n","-",quirm.getLetters(),"letters",quirm.getPackages(),"packages");
            System.out.println("Thank you for using the Ankh-Morpork Post Office. Goodbye!");
        }
    }
}
